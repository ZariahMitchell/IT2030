﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FutureValue.Models
{
    public class FutureValueModel
    {
        [Required(ErrorMessage = "Please enter a subtotal.")]
        [Range(1, 2147483647, ErrorMessage = "Subtotal must be greater than 0.")]
        public decimal? Subtotal { get; set; }

        [Required(ErrorMessage = "Please enter a discount percent.")]
        [Range(0, 100, ErrorMessage = "Discount percent  must be between 0 and 100.")]
        public decimal? DiscountPercent { get; set; }

        public decimal? CalculateDiscount()
        {
            int? discountAmount = (int?)(Subtotal * (DiscountPercent / 100));
            return discountAmount;
        }

        public decimal? CalculateTotal()
        {
            int? discountAmount = (int?)(Subtotal * (DiscountPercent / 100));
            int? total = (int)(Subtotal - discountAmount);
            return total;
        }


    }
}
